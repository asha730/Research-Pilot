class ResearchBiasDetector:
    def __init__(self):
        self.geographic_keywords = ["US-based", "Western", "European", "Urban"]
        self.demographic_keywords = ["undergraduate students", "male-only", "limited sample"]

    def detect_biases(self, papers):
        """
        Feature 14: Research Bias Detection
        Critiques the diversity and methodology of the research pool.
        """
        if not papers: return []

        detected_biases = []
        
        # 1. Geographic Bias Analysis
        # Checking if journals or titles suggest a localized focus
        geo_mentions = [p.get('journal', '') for p in papers if any(k in p.get('journal', '') for k in ["American", "European", "British"])]
        if len(geo_mentions) > len(papers) * 0.5:
            detected_biases.append({
                "category": "Geographic",
                "label": "Western-Centric Bias",
                "impact": "Findings may not generalize to Global South or diverse cultural contexts."
            })

        # 2. Methodology Bias (Feature 13 & 14)
        # Check if papers are all from the same era or use the same citation loops
        avg_year = sum([p['year'] for p in papers]) / len(papers)
        if avg_year < 2018:
            detected_biases.append({
                "category": "Temporal",
                "label": "Historical Staleness",
                "impact": "Heavy reliance on older frameworks; may miss recent breakthroughs."
            })

        # 3. Data Source Bias
        detected_biases.append({
            "category": "Dataset",
            "label": "Homogeneous Data Sources",
            "impact": "Potential over-fitting to specific benchmark datasets (e.g., ImageNet, MNIST)."
        })

        return detected_biases