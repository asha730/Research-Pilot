from langchain_community.vectorstores import Chroma
from langchain_huggingface import HuggingFaceEmbeddings

class ResearchMemory:
    def __init__(self):
        # This converts text into 768-dimensional mathematical vectors
        self.embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
        self.db = None

    def store_papers(self, papers):
        """Feature 20: Living Research Knowledge Memory"""
        texts = [p['title'] for p in papers]
        metadatas = [{"journal": p['journal'], "year": p['year']} for p in papers]
        
        # This creates a local database in your folder
        self.db = Chroma.from_texts(
            texts=texts, 
            embedding=self.embeddings, 
            metadatas=metadatas,
            persist_directory="./research_db"
        )
        print(f"Memory Updated: {len(texts)} papers vectorized.")

    def find_similar(self, query: str):
        """Feature 4: Semantic Similarity Search"""
        if not self.db: return []
        return self.db.similarity_search(query, k=3)