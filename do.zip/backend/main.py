from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import requests

# Import the new Intelligence Layer components
from orchestrator import ResearchOrchestrator

try:
    from utils import calculate_importance
except ImportError:
    def calculate_importance(p): return 50.0

app = FastAPI()

# --- THE BRIDGE (CORS) ---
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize the Research Intelligence Orchestrator (Feature 19)
# This coordinates Memory, Extraction, and Reasoning
orchestrator = ResearchOrchestrator()

@app.get("/")
def home():
    return {
        "status": "Online", 
        "system": "ResearchPilot Intelligence Engine",
        "features_active": ["Structured Extraction", "Vector Memory", "Consensus Detection"]
    }

@app.get("/search")
def search_papers(topic: str):
    """
    Core Research Pipeline:
    1. Discovery (OpenAlex)
    2. Importance Scoring (Custom Logic)
    3. Intelligence Orchestration (Structured Extraction & Memory)
    """
    # Feature 1: Autonomous Paper Discovery
    url = f"https://api.openalex.org/works?search={topic}&filter=has_doi:true"
    
    try:
        response = requests.get(url, timeout=10)
        data = response.json()
        
        raw_papers = []
        
        for work in data.get('results', []):
            title = work.get("display_name", "Untitled Paper")
            year = work.get("publication_year", 0)
            citations = work.get("cited_by_count", 0)
            doi = work.get("doi", "#")
            
            loc = work.get("primary_location") or {}
            source = loc.get("source") or {}
            journal_name = source.get("display_name", "Unknown Journal")
            
            paper_data = {
                "title": title,
                "year": year,
                "cited_by_count": citations,
                "journal": journal_name,
                "link": doi,
            }
            
            # Feature 13: Research Debt/Importance Scoring
            paper_data["importance_score"] = calculate_importance(paper_data)
            paper_data["status"] = "COMPLETED" if paper_data["importance_score"] > 50 else "VERIFIED"
            paper_data["tags"] = [topic.upper()[:10], "AI_ANALYZED"]
            
            raw_papers.append(paper_data)
        
        # Sort by importance before processing intelligence
        raw_papers = sorted(raw_papers, key=lambda x: x['importance_score'], reverse=True)[:15]

        # --- INTELLIGENCE LAYER (Features 3, 4, 19, 20) ---
        # This transforms raw metadata into structured research intelligence
        intelligence_results = orchestrator.process_search_results(raw_papers)
        
        # Feature 6 & 18: Cross-paper reasoning and Dashboard API
        meta_insights = orchestrator.get_cross_paper_insights()
        
        return {
            "query": topic,
            "count": len(intelligence_results),
            "papers": intelligence_results,
            "reasoning_engine": {
                "consensus": meta_insights["consensus"],
                "confidence": meta_insights["strength_score"],
                "evidence_sources": meta_insights["citations"]
            }
        }

    except Exception as e:
        return {"status": "error", "message": str(e)}