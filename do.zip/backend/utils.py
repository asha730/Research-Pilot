def calculate_importance(paper):
    """
    Our custom ML-style logic to rank 'Genuine' papers.
    It considers Citations (Authority) and Year (Recency).
    """
    citations = paper.get("cited_by_count", 0)
    year = paper.get("publication_year", 2000)
    
    # Simple algorithm: Citations weigh 70%, Recency weighs 30%
    # We normalize these to create a score out of 100
    recency_score = (year - 2010) * 2  # Papers after 2010 get a boost
    citation_score = citations * 0.5   # Each citation adds value
    
    total_score = citation_score + recency_score
    return round(min(total_score, 99.9), 1) # Cap it at 99.9