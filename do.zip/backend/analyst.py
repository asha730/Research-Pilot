from datetime import datetime

class ResearchAnalyst:
    def __init__(self):
        self.current_year = datetime.now().year

    def predict_trajectory(self, papers):
        """
        Feature 11: Research Trajectory Prediction
        Analyzes volume and citations over time.
        """
        if not papers:
            return {"status": "Stable", "momentum": 0}

        # Calculate average age and citation velocity
        years = [p['year'] for p in papers if p['year'] > 0]
        avg_year = sum(years) / len(years) if years else self.current_year
        
        # High velocity = recent papers with high citations
        velocity = sum([p['cited_by_count'] for p in papers]) / len(papers)
        
        # Feature 13: Research Debt Score (0-100)
        # Saturated topics have old papers and very high citation counts
        debt_score = min(100, (self.current_year - avg_year) * 10)

        if avg_year > self.current_year - 2 and velocity > 20:
            trajectory = "Emerging / Exponential"
        elif debt_score > 60:
            trajectory = "Saturated / High Debt"
        else:
            trajectory = "Steady Growth"

        return {
            "trajectory": trajectory,
            "debt_score": round(debt_score, 2),
            "momentum_index": round(velocity, 2),
            "avg_year": round(avg_year, 1)
        }