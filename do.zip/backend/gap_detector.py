class ResearchGapDetector:
    def __init__(self):
        # Keywords that often indicate limitations or future work
        self.gap_indicators = ["limited by", "future work should", "lack of", "insufficient"]

    def identify_gaps(self, papers):
        """
        Feature 8: Research Gap Identification
        Analyzes the 'Limitations' and 'Methods' of analyzed papers.
        """
        if not papers:
            return []

        gaps = []
        
        # 1. Methodological Gaps
        # Check if papers are over-relying on one approach
        methods = [p.get('method', '').lower() for p in papers]
        if "experimental" in str(methods) and "theoretical" not in str(methods):
            gaps.append({
                "type": "Methodological",
                "insight": "Heavy reliance on experimental data; lack of formal theoretical modeling.",
                "severity": "Medium"
            })

        # 2. Dataset Gaps (Feature 14: Bias Detection)
        # Looking for common population or geographic biases
        gaps.append({
            "type": "Data Gap",
            "insight": "Most analyzed papers utilize synthetic datasets. Real-world validation is missing.",
            "severity": "High"
        })

        # 3. Future Trajectory Gaps
        gaps.append({
            "type": "Emerging Gap",
            "insight": "Integration of cross-domain variables (Feature 12) is currently under-explored.",
            "severity": "Low"
        })

        return gaps