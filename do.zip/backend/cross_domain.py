class CrossDomainMapper:
    def __init__(self):
        # A library of frameworks from diverse fields
        self.frameworks = {
            "Cybersecurity": "Zero-Trust Architecture / Blockchain Verification",
            "Biology": "Evolutionary Algorithms / Genetic Adaptation",
            "Finance": "Risk-Hedge Models / Monte Carlo Simulations",
            "Architecture": "Modular Design / Structural Integrity",
            "Social Science": "Network Theory / Behavioral Incentives"
        }

    def suggest_transfer(self, topic, problem):
        """
        Feature 12: Cross-Domain Idea Transfer
        Maps solutions from unrelated domains to the current problem.
        """
        # Logic: If the problem involves 'Security', suggest 'Cybersecurity'
        # If the problem involves 'Optimization', suggest 'Biology'
        
        suggestions = []
        
        prob_lower = problem.lower()
        
        if "security" in prob_lower or "trust" in prob_lower:
            suggestions.append({
                "source_domain": "Cybersecurity",
                "transfer_concept": self.frameworks["Cybersecurity"],
                "reasoning": "Standard security protocols in this field can be enhanced using zero-trust verification."
            })
            
        if "optimization" in prob_lower or "efficiency" in prob_lower:
            suggestions.append({
                "source_domain": "Biology",
                "transfer_concept": self.frameworks["Biology"],
                "reasoning": "Biological adaptation patterns can optimize resource allocation here."
            })

        # Default 'out of the box' suggestion if no keywords match
        if not suggestions:
            suggestions.append({
                "source_domain": "Finance",
                "transfer_concept": self.frameworks["Finance"],
                "reasoning": "Applying high-frequency risk-hedge models could stabilize the current variable results."
            })

        return suggestions